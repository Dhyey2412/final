const decode = require("jwt-decode");

const verifyRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req?.headers?.authorization) {
      console.log("check ");
      return res.sendStatus(401);
    }
    const token = req.headers.authorization;
    const decodedToken = decode?.jwtDecode(token);
    if (decodedToken) {
      const rolesArr = decodedToken?.UserInfo?.roles;

      const rolesArray = [...allowedRoles];
      console.log("roles arr", rolesArray, "rolesArr", rolesArr);
      const result = rolesArr
        .map((role) => rolesArray.includes(role))
        .find((val) => val === true);

      console.log("result", result);

      if (!result) return res.sendStatus(401);
      next();
    } else {
      return res.sendStatus(401);
    }
  };
};

module.exports = verifyRoles;
