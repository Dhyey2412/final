const ROLES_LIST = {
  "SUPER_ADMIN": 1545,
  "ADMIN": 1789,
  "SUB_ADMIN": 1768,
   "USER" : 1987
}

module.exports = ROLES_LIST