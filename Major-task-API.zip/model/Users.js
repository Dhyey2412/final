const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    roles: {
        USER: {
            type: Number,
            default: 1987
        },
        SUB_ADMIN: Number,
        ADMIN: Number,
        SUPER_ADMIN : Number
    },
    password: {
        type: String,
        required: true
    },
    refreshToken: [String]
});

module.exports = mongoose.model('User', userSchema);