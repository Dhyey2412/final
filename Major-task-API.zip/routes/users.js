const express = require('express');
const router = express.Router();
const usersController = require('../controllers/users.js');
const ROLES_LIST = require('../config/roles.js');
const verifyRoles = require('../middleware/verifyRoles.js');

router.route('/')
    .get(verifyRoles(ROLES_LIST.SUPER_ADMIN), usersController.getAllUsers)
    .post(verifyRoles(ROLES_LIST.SUPER_ADMIN), usersController.createUser )
    .delete(verifyRoles(ROLES_LIST.SUB_ADMIN), usersController.deleteUser);

router.route('/:id')
    .get(verifyRoles(ROLES_LIST.SUB_ADMIN), usersController.getUser);

module.exports = router;