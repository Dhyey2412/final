const express = require('express');
const router = express.Router();
const employeesController = require('../controllers/employees');
const ROLES_LIST = require('../config/roles');
const verifyRoles = require('../middleware/verifyRoles');

router.route('/')
    .get(employeesController.getAllEmployees)
    .post(verifyRoles(ROLES_LIST.SUPER_ADMIN, ROLES_LIST.ADMIN, ROLES_LIST.SUB_ADMIN), employeesController.createNewEmployee)
    .put(verifyRoles(ROLES_LIST.SUPER_ADMIN, ROLES_LIST.ADMIN), employeesController.updateEmployee)
    .delete(verifyRoles(ROLES_LIST.SUPER_ADMIN), employeesController.deleteEmployee);

router.route('/:id')
    .get(employeesController.getEmployee);

module.exports = router;